import axios from "axios";
import { BASE_URL } from "./APIconstants";
import { getToken } from "./TokenUtil";

export async function DoctorServices(){
    try{
        const doctorData= await axios.get(`${BASE_URL}/book-appointment`,{headers:{'Authorization':`Bearer ${getToken()}`}});
    return doctorData.data;
    }
    catch(error){
        console.log(error);
    }
}

export async function BookAppointment(booking){
    try{
        const response= await axios.post(`${BASE_URL}/book-appointment`,booking,{headers:{'Authorization':`Bearer ${getToken()}`}});
    return response.data;
    }
    catch(error){
        console.log(error);
    }
}