import { Col, Container, Image, Row } from "react-bootstrap";
import profilepagepic from "../Photos/Mentalhealth1.png";
import { getUserProfile } from "../services/UserServices";


export function Profile(){
    const userProfile=getUserProfile("user1");
    
    return(
        <Container>
            <Row>
                <Col md={{ span: 10, offset: 1 }}>
                <img src={profilepagepic} width="1000"/>
                </Col>
            </Row>
            <Row>
                <Col md={{ span: 3, offset: 5 }}>
                    <h4>Username : {userProfile.username}</h4>
                    <h4>Email : {userProfile.email}</h4>
                    <h4>Date Of Birth: {userProfile.dob}</h4>
                    <h4>Gender : {userProfile.gender}</h4>
                    <h4>City : {userProfile.city}</h4>
                    <h4>State : {userProfile.state}</h4>
                    <h4>Phone : {userProfile.phone}</h4>
                </Col>
            </Row>
        </Container>
    );
}