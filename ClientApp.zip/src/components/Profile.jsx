import { Col, Container, Row, Table } from "react-bootstrap";
import profilepagepic from "../Photos/Mentalhealth1.png";
import { getUserProfile } from "../services/UserServices";
import { useState, useEffect } from "react";

export function Profile() {
    const [user, setUsers] = useState({ username: "", email: "", dob: "", gender: "", city: "", state: "", phone: "" });
    const [bookings, setBookings] = useState([]);
    const getUserInfo = async () => {
        try {
            const result = await getUserProfile();
            setUsers(result.user);
            setBookings(result.booking);
        } catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        getUserInfo();
    }, []);

    return (
        <>
            <Container>
                <Row>
                    <Col md={{ span: 10, offset: 1 }}>
                        <img src={profilepagepic} width="1000" alt="" />
                    </Col>
                </Row>
                <Row>
                    <Col md={{ span: 3, offset: 5 }}>
                        <h4>Username : {user.username}</h4>
                        <h4>Email : {user.email}</h4>
                        <h4>Date Of Birth : {user.dob}</h4>
                        <h4>Gender : {user.gender}</h4>
                        <h4>City : {user.city}</h4>
                        <h4>State : {user.state}</h4>
                        <h4>Phone : {user.phone}</h4>
                    </Col>
                </Row>
            </Container>
            <Container>
                <Table className="mt-4">
                    <thead>
                        <tr>
                            <th>Name of Doctor</th>
                            <th>Appointment Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            bookings.map((d) => {
                                return (
                                    <tr>
                                        <td>{d.doctor_id}</td>
                                        <td>{d.date}</td>
                            
                                    </tr>

                                )
                            })
                        }
                    </tbody>
                </Table>
            </Container>
        </>
    );
}