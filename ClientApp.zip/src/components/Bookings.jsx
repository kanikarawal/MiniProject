import React, { useEffect, useState } from 'react';
import Image from 'react-bootstrap/Image';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import BookEditImage from '../Photos/bookings.jpg';
import { BookAppointment, DoctorServices } from '../services/DoctorServices';
import { Container, Form, Table } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

export function Bookings(){
  const navigate = useNavigate();
  const [doctors, setDoctors] = useState([]);
  async function populateDoctorState() {
    try {
        const doctorData = await DoctorServices();
        setDoctors(doctorData.Doctor);
    } catch (error) {
        console.log(error);
    }
}

useEffect(() => {
  populateDoctorState();
}, []);

const [bookingDate, setBookingDate] = useState("");

const handleBookingDateChange=(e) => {
  setBookingDate(e.target.value);
}

const handleSubmit=(dctr_id)=>{
const booking={doctor_id:dctr_id, date:bookingDate}
const result=BookAppointment(booking);
navigate("/myprofile");

}


return(
  <>
<Container>
            
 <Table className="mt-4">
    <thead>
        <tr>
            <th>Name</th>
            <th>Area</th>
            <th>Profile</th>
            <th>Enter date</th>
            <th>Book Now</th>
        </tr>
    </thead>
    <tbody>
        {
            doctors.map((d) => {
                return (
                    <tr>
                        <td>{d.name}</td>
                        <td>{}</td>
                        <td>{d.profile}</td>
                        
                        <td>
                            <input type="date" name="date" onChange={handleBookingDateChange} />
                        </td>
                        <td>
                        <Button variant="primary" onClick={() => handleSubmit(d.name)}>Book Now</Button>
                            {/* <Button variant="primary" onClick={()=>{
                                navigate(`/book-appointment/${d.doctor_id}`)
                            }}>Book Now</Button> */}
                        </td>
    
                    </tr>
                  
                )
            })
        }
    </tbody>
</Table> 
</Container>
</>
);
      }
  // old code
  // const [doctors, setDoctors] = useState({name:"",profile:"",area:""});
  // const populateDoctorState=async()=>  {
  //   try {
  //     const doctorsData = await DoctorServices();
  //     console.log(doctorsData);
  //     setDoctors(doctorsData.doctors);
  //     console.log(doctors);
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }

  // useEffect(() => {
  //   populateDoctorState();
  //   console.log("Hello");
  // }, []); YAHA TAK HAI OLD CODE

  // doctors.map((d) => {
  //   return (
  //     <>
  //       <Image src={BookEditImage} fluid />

  //       <Row className="justify-content-between px-4 mt-4">
  //         <Col xs={12} sm={4} className="mb-4">
  //           <Card style={{ width: '18rem' }}>
  //             <Card.Img variant="top" src="" />
  //             <Card.Body className="text-center">
  //               {/* <Card.Title>{d.name}</Card.Title> */}
  //               <Card.Text>
  //                 {/* {d.profile}<br/>
  //                 {d.area} */}
  //               </Card.Text>
  //               <Button variant="primary">Ready to Book?</Button>
  //               <p></p>
  //               <Button variant="danger">Cancel Booking</Button>
  //             </Card.Body>
  //           </Card>
  //         </Col>
  //       </Row>
  //     </>
  //   );
  // // });


  {/* <Col xs={12} sm={4} className="mb-4">
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src="" />
            <Card.Body className="text-center">
              <Card.Title>Dr 2</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of the card's content.
              </Card.Text>
              <Button variant="primary">Ready to Book?</Button>
              <p></p>
              <Button variant="danger">Cancel Booking</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} sm={4} className="mb-4">
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src="" />
            <Card.Body className="text-center">
              <Card.Title>Dr 3</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of the card's content.
              </Card.Text>
              <Button variant="primary">Ready to Book?</Button>
              <p></p>
              <Button variant="danger">Cancel Booking</Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row className="justify-content-between px-4 mt-4">
        <Col xs={12} sm={6} className="mb-4">
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src="" />
            <Card.Body className="text-center">
              <Card.Title>Dr 4</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of the card's content.
              </Card.Text>
              <Button variant="primary">Ready to Book?</Button>
              <p></p>
              <Button variant="danger">Cancel Booking</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col xs={12} sm={6} className="mb-4">
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src="" />
            <Card.Body className="text-center">
              <Card.Title>Dr 5</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up the bulk of the card's content.
              </Card.Text>
              <Button variant="primary">Ready to Book?</Button>
              <p></p>
              <Button variant="danger">Cancel Booking</Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </> */}
//   {/* );
// } */}

