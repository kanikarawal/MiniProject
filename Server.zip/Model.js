import mongoose, { Schema } from "mongoose";

const userSchema = new Schema({
    username: String,
    us_name: String,
    email: String,
    password: String,
    dob: String,
    gender: String,
    city: String,
    state: String,
    phone: String
});
export const User = mongoose.model("user", userSchema, "user_info");

const doctorSchema = new Schema({
    doctor_id:String,
    name:String,
    profile:String,
    area:String
});
export const Doctor = mongoose.model("doctor_info", doctorSchema, "doctor_info");
const d1Schema = new Schema({
    booking_date:String,
    status:String    
});
export const D1 = mongoose.model("d1", d1Schema,"D001_bookings");

const d2Schema = new Schema({
    booking_date:String,
    status:String    
});
export const D2 = mongoose.model("d2", d2Schema,"D002_bookings");

const d3Schema = new Schema({
    booking_date:String,
    status:String    
});
export const D3 = mongoose.model("d3", d3Schema,"D003_bookings");

const d4Schema = new Schema({
    booking_date:String,
    status:String    
});
export const D4 = mongoose.model("d4", d1Schema,"D004_bookings");

const d5Schema = new Schema({
    booking_date:String,
    status:String    
});
export const D5 = mongoose.model("d5", d1Schema,"D005_bookings");


const bookSchema = new Schema({
    dctr_id:String,
    bookingdate:String,
    status:String    
});
export const Booked = mongoose.model("booked", bookSchema,"booked");